# QuizApp
This app implements use of differenet nested layouts and different buttons, textboxes and intent (for sharing score). 
 
 Pre-requisites
--------------

- Android SDK v27
- Android Build Tools v27.0.1
- Android Support Repository v27.0.1

Getting Started
---------------

This sample uses the Gradle build system. To build this project, use the
"gradlew build" command or use "Import Project" in Android Studio.
 


